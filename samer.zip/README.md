# Restart Impact Week

### Team: TripleS
### Year: 2017

This project is for Samer Abdelnuer.

## Coders:
* Sheril
* Shahriyar
* [Shahrokh Nabavi](http://www.nabavi.nl)
