 <!-- Footer -->
    <div class="footer">
    	<div class="container">
    		<p class="m-0 text-center text-white">Copyright &copy; Triple S.S.S</p>
    	</div>
    </div>
    <!-- /. Footer -->


    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo base_url('assets/vendor/bootstrap/js/video.js');?>"></script>
    <script src="<?php echo base_url('assets/vendor/jquery/jquery.min.js');?>"></script>
    <script src="<?php echo base_url('assets/vendor/popper/popper.min.js');?>"></script>
    <script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.min.js');?>"></script>
    <script src="http://pupunzi.com/mb.components/mb.YTPlayer/demo/inc/jquery.mb.YTPlayer.js"></script>

  </body>

</html>