<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('users/include/header')
?>

    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
    <br><br><br><br>
    <h3> ABOUT ME </h3>
    <br><br>
    <p> Some text or photo comes here soon... Some text or photo comes here soon....<br>
    Some text or photo comes here soon.... Some text or photo comes here soon....<br>
    Some text or photo comes here soon....Some text or photo comes here soon....</p>

    </div>
      </div>
        </div>
    <!-- /.container -->

    <!-- 
         footer -->

  <?php
  defined('BASEPATH') OR exit('No direct script access allowed');
  $this->load->view('users/include/footer')
  ?>
   