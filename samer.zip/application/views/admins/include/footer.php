<?php
/**
 * Created Shahrokh Nabavi.
 * Date: 8/28/2017
 * Time: 6:11 PM
 */
defined('BASEPATH') OR exit('No direct script access allowed');
?>
                    </div>
                </div>
                <!--/col-span-9-->
            </div>
        </div>

    <footer class="text-center">Copyright 2017. Build by <a href="http://www.nabavi.nl"><strong>Nabavi.nl</strong></a></footer>
    </div>
    <!-- /Main -->
    <!-- script references -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="<?= base_url('assets/js/scripts.js'); ?>"></script>
</body>
</html>